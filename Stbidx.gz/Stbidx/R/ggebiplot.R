
#' performing genotype plus genotype by environment (GGE) model
#'
#' This function takes the raw data in excel file format as input and calculates the stability based on GGE model.
#' @param ggebiplot() nothing required to get filled in the parenthesis.
#' @return GGE biplot and three plot along with other related information.
#' @export
#' @examples
#' ggebiplot()

ggebiplot <- function(){
library(readxl)
library(gge)

df <- read_excel(file.choose(), sheet = 1)
ti <- c("environment", "genotype", "block", "yield")
colnames(df) <- ti
View(df)

gge1 <- gge(df, yield~genotype*environment,
            env.group=environment, scale=FALSE)
plot(gge1)
biplot(gge1, lab.env=TRUE,
       main="GGE Biplot for tricticale genotypes")
}
