
#' performing AMMI model
#'
#' This function takes the raw data in excel file format as input and calculates the stability based on AMMI model.
#' @param ammi() nothing required to get filled in the parenthesis.
#' @return AMMI ANOVA, and related information.
#' @export
#' @examples
#' ammi()

ammi <- function(){
library(readxl)
df <- read_excel(file.choose(), sheet = 1)
ti <- c("environment", "genotype", "block", "yield")
colnames(df) <- ti
View(df)

library(agricolae)

model<- with(df, AMMI(environment, genotype,
                      block, yield, console=TRUE))
model$ANOVA
model$analysis
model$biplot

plot(model)
plot(model, type=2, number=TRUE)
plot(model, first=0,second=1, number=TRUE)

ir <- getwd()
dir1 <- paste(ir,"/anova.csv", sep="")
dir2 <- paste(ir,"/analysis.csv", sep="")
dir3 <- paste(ir,"/biplot.csv", sep="")
write.csv(model$ANOVA, dir1)
write.csv(model$analysis, dir2)
write.csv(model$biplot, dir3)

}
