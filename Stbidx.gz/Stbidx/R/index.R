
#' Calculating all univariate stability indices
#'
#' This function takes the raw data in excel file format as input and calculates the univariate stability indices.
#' these indices are containing:
#' @param index() nothing required to get filled in the parenthesis.
#' @return all univariate indices and scatter plot for yield by CV.
#' @export
#' @examples
#' index()

index <- function(){
library(readxl)

df <- read_excel(file.choose(), sheet = 1)
ti <- c("environment", "genotype", "block", "yield")
colnames(df) <- ti
View(df)

library(tidyverse)
library(dplyr)

d <- df[order(df$environment, df$genotype),]
avg <- aggregate(d$yield, list(d$environment, d$genotype),
                 mean)
ti1 <- c("environment", "genotype", "yield")
colnames(avg) <- ti1
avg <- avg[order(avg$environment, avg$genotype),]
#View(avg)
me <- aggregate(df$yield, list(df$environment),
                 mean)
ne <- nrow(me); tot <- nrow(avg); ng <- tot/ne
env <- me[, 1]
mg <- aggregate(df$yield, list(df$genotype), mean)
gen <- mg[,1]

mat <- matrix(avg$yield, ng, ne)
#View(mat)

colnames(mat) <- env
rownames(mat) <- gen

mi <- as.matrix(rowMeans(mat)); colnames(mi) <- "m"
mg <- matrix(mi, ng, ne)
mj <- t(as.matrix(colMeans(mat)))
me <- t(matrix(mj, ne, ng))
mt <- matrix(mean(mat), ng, ne)


ss <- (mat - mg)^2;
s2 <- as.matrix(rowSums(ss)/ne)

CV <- as.matrix((sqrt(s2)/mi)*100)

W2 <- as.matrix(rowSums((mat - mg - me + mt)^2))

o1 <- (ne/((ng-2)*(ne-1)))
o2 <- ((ng-2)*(ng-1)*(ne-1))
ssg <- as.matrix(rowSums(ss))
sig2 <- as.matrix(o1*W2-(ssg/o2))

ssr <- as.matrix(rowSums((mat - mg) * (me - mt)))
sse <- as.matrix(rowSums((me - mt)^2))
b <- ssr/sse

l<-(rowSums(((mat - mg)^2)) * ((b^2)*(rowSums((me - mt)^2))))
l1 <- (ne-2)
sd <- sqrt(l/l1)

R2<-((b^2)*(rowSums((me - mt)^2)))/(rowSums(((mat - mg)^2)))


indx <- cbind(mi, s2, CV, W2, sig2, b, sd, R2)
cln <- c("Yi", "S2", "CV", "W2", "sig2",
           "b", "sd", "R2")
colnames(indx) <- cln
rownames(indx) <- gen
View(indx)

ir <- getwd()
dir <- paste(ir,"/Index.csv", sep="")
write.csv(indx, dir)

plot(mi~CV,
     xlab = "Genotyp Coefficient of Variation (%)",
     ylab = "Grain Yield",
)
text(mi~CV, labels=rownames(mi),cex=1.5, font=2)

abline(h = mean(mi) , col="gray")
abline(v = 50 , col="gray")

require(ggcorrplot)
corr <- round(cor(indx), 2)
pc <- cor_pmat(indx); pc

ggcorrplot(corr, method = "square", lab = TRUE, digit=2,
           p.mat = pc, sig.level =0.05,
           colors = c('blue', 'white', 'red'))

}
