
#' Calculating the proposed stability ID (SID)
#'
#' This function takes the raw data in excel file format as input and calculates the rank of univariate stability indices and transform them into one single index SID and the final ran for the determining stable genotypes would be prepared.
#' @param sid() nothing required to get filled in the parenthesis.
#' @return rank of all univariate indices and stability ID.
#' @export
#' @examples
#' sid()

sid <- function(){
library(readxl)
df <- read_excel(file.choose(), sheet = 1)
ti <- c("environment", "genotype", "block", "yield")
colnames(df) <- ti
View(df)

library(tidyverse)
library(dplyr)

d <- df[order(df$environment, df$genotype),]
avg <- aggregate(d$yield, list(d$environment, d$genotype),
                 mean)
ti1 <- c("environment", "genotype", "yield")
colnames(avg) <- ti1
avg <- avg[order(avg$environment, avg$genotype),]
#View(avg)
me <- aggregate(df$yield, list(df$environment),
                mean)
ne <- nrow(me); tot <- nrow(avg); ng <- tot/ne
env <- me[, 1]
mg <- aggregate(df$yield, list(df$genotype), mean)
gen <- mg[,1]

mat <- matrix(avg$yield, ng, ne)
#View(mat)

colnames(mat) <- env
rownames(mat) <- gen

mi <- as.matrix(rowMeans(mat)); colnames(mi) <- "m"
mg <- matrix(mi, ng, ne)
mj <- t(as.matrix(colMeans(mat)))
me <- t(matrix(mj, ne, ng))
mt <- matrix(mean(mat), ng, ne)


ss <- (mat - mg)^2;
s2 <- as.matrix(rowSums(ss)/ne)

CV <- as.matrix((sqrt(s2)/mi)*100)

W2 <- as.matrix(rowSums((mat - mg - me + mt)^2))

o1 <- (ne/((ng-2)*(ne-1)))
o2 <- ((ng-2)*(ng-1)*(ne-1))
ssg <- as.matrix(rowSums(ss))
sig2 <- as.matrix(o1*W2-(ssg/o2))

ssr <- as.matrix(rowSums((mat - mg) * (me - mt)))
sse <- as.matrix(rowSums((me - mt)^2))
b <- ssr/sse

l<-(rowSums(((mat - mg)^2)) * ((b^2)*(rowSums((me - mt)^2))))
l1 <- (ne-2)
sd <- sqrt(l/l1)

R2<-((b^2)*(rowSums((me - mt)^2)))/(rowSums(((mat - mg)^2)))


indx <- cbind(mi, s2, CV, W2, sig2, b, sd, R2)
cln <- c("Yi", "S2", "CV", "W2", "sig2",
         "b", "sd", "R2")
colnames(indx) <- cln
rownames(indx) <- gen
#View(indx)


rownames(mi)    <- gen
rownames(s2)    <- gen
rownames(CV)    <- gen
rownames(W2)    <- gen
rownames(sig2)  <- gen
rownames(b)     <- gen
rownames(sd)    <- gen
rownames(R2)    <- gen


Rs2   <- as.matrix(rank(s2))
RCV   <- as.matrix(rank(CV))
RW2   <- as.matrix(rank(W2))
Rsig2 <- as.matrix(rank(sig2))
Rb    <- as.matrix(rank(b))
Rsd   <- as.matrix(rank(sd))
RR2   <- as.matrix(rank(R2))

rownames(Rs2)    <- gen
rownames(RCV)    <- gen
rownames(RW2)    <- gen
rownames(Rsig2)  <- gen
rownames(Rb)     <- gen
rownames(Rsd)    <- gen
rownames(RR2)    <- gen



R <- cbind(Rs2, RCV, RW2, Rsig2, Rb, Rsd, RR2)
cn<- c("RS2", "RCV", "RW2", "Rsig2", "Rb", "Rsd", "RR2")
colnames(R) <- cn

SID <- as.matrix(rowMeans(R))
rownames(SID)    <- gen

RSID <- as.matrix(rank(SID))
rownames(RSID)    <- gen

rnk <- cbind(SID, RSID)
colnames(rnk) <- c("SID", "RSID")
View(rnk)

ir <- getwd()
dir1 <- paste(ir,"/SID.csv", sep="")
dir2 <- paste(ir,"/Rank.csv", sep="")
write.csv(rnk, dir1)
write.csv(R, dir2)

plot(mi~RSID,
     xlab = "Genotyp Rank (RSID)",
     ylab = "Grain Yield",
)
text(mi~RSID, labels=rownames(mi),cex=1.5, font=2)

abline(h = mean(mi) , col="gray")
abline(v = mean(RSID) , col="gray")

library(xlsx); library(agricolae); require(gplots)
matc.scl <- scale(mat)
heatmap.2(matc.scl, margins = c(8, 6))

}
